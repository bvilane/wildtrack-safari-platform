const BASE_URL = 'http://localhost:5000/api'

export async function getSightings() {
  try {
    const res = await fetch(`${BASE_URL}/sightings`)
    return await res.json()
  } catch (err) {
    console.error("Failed to fetch sightings", err)
    return []
  }
}
