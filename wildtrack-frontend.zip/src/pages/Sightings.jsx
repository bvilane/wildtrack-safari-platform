import React, { useEffect, useState } from "react";

const BACKEND_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";

const Sightings = () => {
  const [sightings, setSightings] = useState([]);

  useEffect(() => {
    const fetchSightings = async () => {
      try {
        const response = await fetch(`${BACKEND_URL}/api/sightings`);
        const data = await response.json();
        setSightings(data);
      } catch (error) {
        console.error("Failed to fetch sightings:", error);
      }
    };

    fetchSightings();
  }, []);

  return (
    <div className="container">
      <h2>Recent Sightings</h2>
      {sightings.length === 0 ? (
        <p>No sightings available.</p>
      ) : (
        sightings.map((sighting, index) => (
          <div className="sighting-card" key={index}>
            <p><strong>Species:</strong> {sighting.species}</p>
            <p><strong>Location:</strong> {sighting.location}</p>
            <p><strong>Coordinates:</strong> {sighting.latitude}, {sighting.longitude}</p>
            <p><strong>Observer:</strong> {sighting.observer}</p>
            <p><strong>Status:</strong> {sighting.verified ? "Verified" : "Unverified"}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default Sightings;
