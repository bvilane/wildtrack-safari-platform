import React from "react";

export default function Home() {
  return (
    <div className="home">
      <h2>Welcome to WildTrack</h2>
      <p>Real-time wildlife sightings from safari lodges.</p>
      <img src="/animals/lion.jpg" alt="Lion" className="banner" />
    </div>
  );
}
