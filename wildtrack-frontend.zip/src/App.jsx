import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Sightings from "./pages/Sightings";
import "./App.css";

function App() {
  return (
    <div className="container">
      <h1>WildTrack Safari Platform</h1>
      <nav>
        <Link to="/">Home</Link> | <Link to="/sightings">Sightings</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/sightings" element={<Sightings />} />
      </Routes>
    </div>
  );
}

function Home() {
  return (
    <div style={{ textAlign: "center", padding: "2rem" }}>
      <h2>Welcome to the WildTrack Safari Platform 🦁</h2>
      <p>Track wildlife sightings in real-time from anywhere in the world.</p>
      <img
        src="https://source.unsplash.com/800x400/?safari,animals"
        alt="Safari"
        style={{ borderRadius: "10px", marginTop: "1rem", maxWidth: "100%" }}
      />
    </div>
  );
}

export default App;
