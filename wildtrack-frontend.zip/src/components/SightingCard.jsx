import React from "react";

export default function SightingCard({ animal, location, gps, observer, verified }) {
  return (
    <div className="card">
      <img src={`/animals/${animal.toLowerCase()}.jpg`} alt={animal} />
      <h3>{animal}</h3>
      <p><strong>Location:</strong> {location}</p>
      <p><strong>GPS:</strong> {gps}</p>
      <p><strong>Observer:</strong> {observer}</p>
      <p className={verified ? "verified" : "pending"}>
        {verified ? "Verified" : "Pending Verification"}
      </p>
    </div>
  );
}
